package com.aungpyaephyo.jsonparsingtutorial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class FriendListAdapter extends BaseAdapter {
    Context context;
    List<Friend> data;
    public FriendListAdapter(Context context, List<Friend> data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View friendView = LayoutInflater.from(context).inflate(R.layout.friend_item, parent, false);
        TextView name = friendView.findViewById(R.id.name);
        TextView job = friendView.findViewById(R.id.job);
        name.setText(data.get(position).getName());
        job.setText(data.get(position).getJob());
        return friendView;
    }
}
