package com.aungpyaephyo.jsonparsingtutorial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    List<Friend> data;
    FriendListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list);
        data = new ArrayList<>();

        adapter = new FriendListAdapter(this, getFriends());
        listView.setAdapter(adapter);

    }

    private List<Friend> getFriends() {
        List<Friend> result = new ArrayList<>();
        result.clear();

        try {
            JSONArray jsonArray = new JSONArray(readJsonFileFromAsset());
            for (int i = 0; i < jsonArray.length(); i++) {
                String name = jsonArray.getJSONObject(i).getString("name");
                String job = jsonArray.getJSONObject(i).getString("job");
                Friend friend = new Friend(name, job);
                result.add(friend);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return result;
    }

    private String readJsonFileFromAsset() {
        String friendJson = null;
        try {
            InputStream is = getAssets().open("friends.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            friendJson = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }
        return friendJson;
    }


}
